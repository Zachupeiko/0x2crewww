package com.example.forbrainapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class DatabaseAdapter {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    public DatabaseAdapter(Context context){
        dbHelper = new DatabaseHelper(context.getApplicationContext());
    }

    // Открытие базы данных
    public DatabaseAdapter open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    // Закрытие базы данных
    public void close(){
        dbHelper.close();
    }

    // Получение всех записей
    private Cursor getAllEntries(){
        String[] columns = new String[] {
                DatabaseHelper.COLUMN_ID,
                DatabaseHelper.COLUMN_NAME,
                DatabaseHelper.COLUMN_YEAR,
                DatabaseHelper.COLUMN_OPT // Добавлен столбец opt
        };
        return database.query(DatabaseHelper.TABLE, columns, null, null, null, null, DatabaseHelper.COLUMN_YEAR + " DESC");
    }

    // Получение всех пользователей
    public List<User> getUsers(){
        ArrayList<User> users = new ArrayList<>();
        Cursor cursor = getAllEntries();
        while (cursor.moveToNext()){
            int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID));
            String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME));
            int year = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_YEAR));
            String opt = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_OPT)); // Получаем значение столбца opt
            users.add(new User(id, name, year, opt));
        }
        cursor.close();
        return users;
    }

    // Получение количества записей
    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, DatabaseHelper.TABLE);
    }

    // Получение пользователя по ID
    public User getUser(long id){
        User user = null;
        String query = String.format("SELECT * FROM %s WHERE %s=?", DatabaseHelper.TABLE, DatabaseHelper.COLUMN_ID);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(id) });
        if(cursor.moveToFirst()){
            String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME));
            int year = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_YEAR));
            String opt = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_OPT)); // Получаем значение столбца opt
            user = new User(id, name, year, opt);
        }
        cursor.close();
        return user;
    }

    // Вставка нового пользователя
    public long insert(User user){
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COLUMN_NAME, user.getName());
        cv.put(DatabaseHelper.COLUMN_YEAR, user.getYear());
        cv.put(DatabaseHelper.COLUMN_OPT, user.getOpt()); // Вставляем значение столбца opt
        return database.insert(DatabaseHelper.TABLE, null, cv);
    }

    // Удаление пользователя
    public long delete(long userId){
        String whereClause = DatabaseHelper.COLUMN_ID + " = ?";
        String[] whereArgs = new String[]{ String.valueOf(userId) };
        return database.delete(DatabaseHelper.TABLE, whereClause, whereArgs);
    }

    // Обновление данных пользователя
    public long update(User user){
        String whereClause = DatabaseHelper.COLUMN_ID + "=" + user.getId();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COLUMN_NAME, user.getName());
        cv.put(DatabaseHelper.COLUMN_YEAR, user.getYear());
        cv.put(DatabaseHelper.COLUMN_OPT, user.getOpt()); // Обновляем значение столбца opt
        return database.update(DatabaseHelper.TABLE, cv, whereClause, null);
    }
}
