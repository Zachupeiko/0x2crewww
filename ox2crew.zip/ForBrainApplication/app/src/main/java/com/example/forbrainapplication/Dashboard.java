package com.example.forbrainapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.VideoView;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import com.example.forbrainapplication.databinding.ActivityDashboardBinding;

public class Dashboard extends DrawerBaseActivity {
    VideoView videoView;
    Button btn;
    Button btn1;
    Button btn2;
    Button btn3;



    ActivityDashboardBinding activityDashboardBinding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityDashboardBinding = ActivityDashboardBinding.inflate(getLayoutInflater());

        setContentView(activityDashboardBinding.getRoot());
        allocateActivityTitle("Let's get started");
        btn = findViewById(R.id.nav_games);
        btn1 = findViewById(R.id.nav_info);
        btn2 = findViewById(R.id.nav_help);
        btn3 = findViewById(R.id.nav_uch);




        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_game= new Intent(Dashboard.this, MainActivity.class);
                startActivity(intent_game);
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_game= new Intent(Dashboard.this, LogicActivity.class);
                startActivity(intent_game);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_game= new Intent(Dashboard.this, HelpActivity.class);
                startActivity(intent_game);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_game= new Intent(Dashboard.this, Uchastniki.class);
                startActivity(intent_game);
            }
        });





    }
}