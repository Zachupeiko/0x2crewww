package com.example.forbrainapplication;

public class User {

    private long id;
    private String name, opt;
    private int year;

    User(long id, String name, int year, String opt){
        this.id = id;
        this.name = name;
        this.year = year;
        this.opt = opt;


    }
    public long getId() {
        return id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    public String getOpt() {
        return opt;
    }

    public void setOpt(String opt) {
        this.opt = opt;
    }

    @Override
    public String toString() {
        return this.name + " : " + this.year+ "this.opt" ;
    }

}