package com.example.forbrainapplication;



import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "userstore.db"; // название базы данных
    private static final int SCHEMA = 2; // обновленная версия базы данных
    static final String TABLE = "users"; // название таблицы в бд

    // названия столбцов
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_YEAR = "year";
    public static final String COLUMN_OPT = "opt"; // новый столбец opt

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, SCHEMA); // увеличена версия до 2
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Создаем таблицу с новым столбцом opt
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_NAME + " TEXT, "
                + COLUMN_YEAR + " INTEGER, "
                + COLUMN_OPT + " TEXT);" // Добавлен новый столбец opt
        );

        // Добавление начальных данных с новым столбцом opt
        db.execSQL("INSERT INTO " + TABLE + " ("
                + COLUMN_NAME + ", " + COLUMN_YEAR + ", " + COLUMN_OPT
                + ") VALUES ('Том Смит', 1981, 'SomeValue');");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Если обновляемся с версии 1, добавляем новый столбец opt
            db.execSQL("ALTER TABLE " + TABLE + " ADD COLUMN " + COLUMN_OPT + " TEXT;");
        } else {
            // Если версия базы данных изменилась полностью, пересоздаем таблицу
            db.execSQL("DROP TABLE IF EXISTS " + TABLE);
            onCreate(db);
        }
    }
}
