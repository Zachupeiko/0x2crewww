package com.example.forbrainapplication;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import com.github.mikephil.charting.components.YAxis;

import com.example.forbrainapplication.databinding.ActivityPersonalBinding;
import com.github.mikephil.charting.utils.Utils;

public class PersonalActivity extends DrawerBaseActivity {
    ActivityPersonalBinding activityPersonalBinding;
    TextView datesTextView;
    private RecyclerView recyclerView;
    private LinearLayout todoListLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityPersonalBinding = ActivityPersonalBinding.inflate(getLayoutInflater());

        setContentView(activityPersonalBinding.getRoot());
        allocateActivityTitle("Personal Page");
        LineChart chart = findViewById(R.id.chartPersonal);
        List<Entry> entries = new ArrayList<>();
        entries.add(new Entry(0, 10f)); // Score and time spent for the first entry
        entries.add(new Entry(1, 20f)); // Score and time spent for the second entry
        entries.add(new Entry(2, 30f)); // Score and time spent for the third entry
        entries.add(new Entry(3, 40f)); // Score and time spent for the fourth entry
        entries.add(new Entry(4, 50f)); // Score and time spent for the fifth entry

        LineDataSet dataSet = new LineDataSet(entries, "Score in hackaton");
        dataSet.setColor(Color.parseColor("#0000FF")); // Set line color to dark yellow

        LineData lineData = new LineData(dataSet);
        chart.setData(lineData);

        // Customize y-axis
        YAxis yAxis = chart.getAxisLeft();
        yAxis.setAxisMinimum(1f); // Minimum value for y-axis (1)
        yAxis.setAxisMaximum(50f); // Maximum value for y-axis (50)

        // Add a description label
        Description description = new Description();
        description.setText("Score ");
        chart.setDescription(description);

        chart.invalidate(); // Refreshes the chart





    }
}
